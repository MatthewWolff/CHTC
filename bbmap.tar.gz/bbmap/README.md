# BBTools bioinformatics tools, including BBMap.
# Author: Brian Bushnell, Jon Rood, Shijie Yao
# Language: Java, Bash
# Information about documentation is in /docs/readme.txt.

# Version 37.93
